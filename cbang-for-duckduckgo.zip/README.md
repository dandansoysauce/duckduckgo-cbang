# ![icon](https://raw.githubusercontent.com/dandansoysauce/duckduckgo-cbang/master/app/images/icon-32.png "icon") !Contextual Bang for DuckDuckGo

This is an **unofficial** DuckDuckGo addon for your browsers. DuckDuckGo Bangs on your context. Customize and mark your bangs as favorite from thousands of premade DuckDuckGo Bangs.

**Get this for Firefox!**

<a href="https://addons.mozilla.org/en-US/firefox/addon/duckduckgo-right-click/">
    <img src="https://blog.mozilla.org/firefox/files/2017/11/FxA-Add-ons-Shopping-Extensions.png" width="150">
</a>

## Contextual !Bang in Action

![sample shot](https://raw.githubusercontent.com/dandansoysauce/duckduckgo-cbang/master/app/resources/cbang_ss1.png)

## Install

	$ npm install

## Development

    npm run dev chrome
    npm run dev firefox
    npm run dev opera
    npm run dev edge

## Build

    npm run build chrome
    npm run build firefox
    npm run build opera
    npm run build edge

## Environment

The build tool also defines a variable named `process.env.NODE_ENV` in your scripts. 

## Tools

* [webextension-toolbox](https://github.com/HaNdTriX/webextension-toolbox)
